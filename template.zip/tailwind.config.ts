import type { Config } from 'tailwindcss'
import { nextui } from '@nextui-org/react'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './node_modules/@nextui-org/theme/dist/**/*.{js,ts,jsx,tsx}'
  ],
  darkMode: 'class',
  theme: {
    container: {
      center: true,
      padding: {
        DEFAULT: '1rem',
        md: '1.5rem',
        lg: '2rem'
      }
    }
  },
  plugins: [
    nextui({
      themes: {
        light: {
          layout: {}, // light theme layout tokens
          colors: {} // light theme colors
        },
        dark: {
          layout: {}, // dark theme layout tokens
          colors: {} // dark theme colors
        },
        modern: {
          extend: 'dark', // Inherit default values from the dark theme
          colors: {
            background: '#020817', // Dark background color
            foreground: '#000000', // White foreground color
            primary: {
              50: '#7f9ae5',
              100: '#6491f2',
              200: '#4e8bf4',
              300: '#3b83f6',
              400: '#2e7bf7',
              500: '#2677f8',
              600: '#1f72f9',
              700: '#1b6cf9',
              800: '#1567fa',
              900: '#0c5dfa',
              DEFAULT: '#0c5dfa', // Default primary color
              foreground: '#ffffff', // White foreground for primary
            },
            focus: '#F182F6', // Focus color
          },
          layout: {
            disabledOpacity: '0.3',
            radius: {
              small: '1px',
              medium: '2px',
              large: '4px',
            },
            borderWidth: {
              small: '1px',
              medium: '2px',
              large: '3px',
            },
          },
        },
                          
      }
    })
  ]
}
export default config
